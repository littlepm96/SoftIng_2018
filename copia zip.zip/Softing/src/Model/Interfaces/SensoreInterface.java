package Model.Interfaces;

import Model.Components.BackupValori;
import Model.Components.Sensore;

public interface SensoreInterface {
	
	public void setSegnale();
	public void setBackup(BackupValori b);

}
