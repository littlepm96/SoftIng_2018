package Model.Components;

public class Area {
	
	int metri_quadri;
	String nominativo;
	int popolazione;
	String coordinate;
	
	public int getArea() {
		return getArea();
	}
	public void setArea(int area) {
		this.metri_quadri = area;
	}
	public String getNominativo() {
		return nominativo;
	}
	public void setNominativo(String nominativo) {
		this.nominativo = nominativo;
	}
	public int getPopolazione() {
		return popolazione;
	}
	public void setPopolazione(int popolazione) {
		this.popolazione = popolazione;
	}
	public String getCoordinate() {
		return coordinate;
	}
	public void setCoordinate(String coordinate) {
		this.coordinate = coordinate;
	}

}
